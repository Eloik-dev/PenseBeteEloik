<!DOCTYPE html>
<html lang="fr-CA">
<head>
    <title>Pense-bête, mes post-it sur le Web</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Pense-bête m'aide à prendre des notes pour ne rien oublier" />
    <meta name="author" content="Christiane Lagacé : https://christianelagace.com">
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">
    <link rel="mask-icon" href="safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#00aba9">
    <meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
    <div class="boite mobile-shell">
        <div class="interieur">
            <header>
                <nav class="menuprincipal">
                    <div class="menumobile">
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                    <ul>
                        <li class="actif"><a href="#">Accueil</a></li>
                        <li><a href="#">Gestion</a></li>
                        <li><a href="#">À propos</a></li>
                    </ul>
                </nav>
                <div class="entete">
                    <h1>Pense-bête</h1>
                    <div class="soustitre">Pour une fois, je ne vais rien oublier!</div>
                </div>
                <div class="sousentete">
                    <img src="medias/commun/entete.png" alt="post-it" />
                </div>
            </header>
            <div class="contenu">
                <h2>Mes notes</h2>
                <p>Lorem ipsum dolor sit amet, <a href="#">consectetur</a> adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                <div class="notes">
                    <div class="unenote"><p>Acheter du lait</p><span class="date">22 janvier 2023</span></div>
                    <div class="unenote"><p>Finir exercice 3 de Web 1 pour le 27 janvier</p><span class="date">21 janvier 2023</span></div>
                    <div class="unenote"><p>Cinéma à 19h vendredi</p><span class="date">20 janvier 2023</span></div>
                </div>
                <p><a class="bouton" href="#">Ajouter une note</a></p>
            </div>
            <footer>
                <a href="#" target="_blank"><img class="social" src="medias/commun/facebook.jpg" alt="Facebook" /></a>
                <a href="#" target="_blank"><img class="social" src="medias/commun/twitter.jpg" alt="Facebook" /></a>
                <a href="#" target="_blank"><img class="social" src="medias/commun/instagram.jpg" alt="Facebook" /></a>
                <a href="#" target="_blank"><img class="social" src="medias/commun/linkedin.jpg" alt="Facebook" /></a>
                <p class="copyright"><a href="https://mailbakery.com/template-store/product/bloom-free-html-email-template">Bloom!</a> - Free HTML Template</p>
            </footer>
        </div>
    </div>
</body>
</html>
